package com.me.service;

import com.me.entity.Customer;

public interface CustomerManager {

	
	public void createCustomer(Customer cust);
}
