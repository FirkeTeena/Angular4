package com.bvk.groceryapp.model;

public class ShoppingList {
	private int shoppingListId;
	private String title;

	public ShoppingList() {
		super();
	}

	public ShoppingList(int shoppingListId, String title) {
		super();
		this.shoppingListId = shoppingListId;
		this.title = title;
	}

	public ShoppingList(String title) {
		super();
		this.title = title;
	}

	public int getShoppingListId() {
		return shoppingListId;
	}

	public void setShoppingListId(int shoppingListId) {
		this.shoppingListId = shoppingListId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}
	
	
}
