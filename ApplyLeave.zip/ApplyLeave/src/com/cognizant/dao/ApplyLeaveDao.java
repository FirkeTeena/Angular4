package com.cognizant.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cognizant.model.ApplyLeave;

@Repository
public interface ApplyLeaveDao extends CrudRepository<ApplyLeave, Long> {

}