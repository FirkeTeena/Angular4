package com.cognizant.service;

import com.cognizant.model.ApplyLeave;

public interface ApplyLeaveService {
	ApplyLeave save(ApplyLeave applyLeave);
}
