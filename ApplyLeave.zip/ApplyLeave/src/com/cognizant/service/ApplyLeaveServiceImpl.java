package com.cognizant.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.dao.ApplyLeaveDao;
import com.cognizant.model.ApplyLeave;

@Service
public class ApplyLeaveServiceImpl implements ApplyLeaveService {
	@Autowired
	private ApplyLeaveDao applyLeaveDao;

	@Override
	public ApplyLeave save(ApplyLeave applyLeave) {
		return applyLeaveDao.save(applyLeave);
	}

}