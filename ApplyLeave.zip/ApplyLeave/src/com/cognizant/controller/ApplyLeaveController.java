package com.cognizant.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.model.ApplyLeave;
import com.cognizant.service.ApplyLeaveService;

@RestController
@RequestMapping("/secure")
public class ApplyLeaveController {

	@Autowired
	private ApplyLeaveService applyLeaveService;

	@RequestMapping(value = "/employee", method = RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ApplyLeave save(ApplyLeave applyLeave) {
		return applyLeaveService.save(applyLeave);
	}
}
