package com.cognizant.model;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "applyleave")
public class ApplyLeave {
	@Id
	@Column(name = "leaveid")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int leaveId;
	private String name;
	private String reason;

	@Column(name = "fromdate")
	private Date fromdate;

	@Column(name = "todate")
	private Date todate;
	private String leaveType;
	private String status;
	private int empid;

	public int getLeaveId() {
		return leaveId;
	}

	public void setLeaveId(int leaveId) {
		this.leaveId = leaveId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public Date getFromDate() {
		return fromdate;
	}

	public void setFromDate(Date fromDate) {
		this.fromdate = fromDate;
	}

	public Date getToDate() {
		return todate;
	}

	public void setToDate(Date toDate) {
		this.todate = toDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getEmpid() {
		return empid;
	}

	public Date getFromdate() {
		return fromdate;
	}

	public void setFromdate(Date fromdate) {
		this.fromdate = fromdate;
	}

	public Date getTodate() {
		return todate;
	}

	public void setTodate(Date todate) {
		this.todate = todate;
	}

	public String getLeaveType() {
		return leaveType;
	}

	public void setLeaveType(String leaveType) {
		this.leaveType = leaveType;
	}

	public void setEmpid(int empid) {
		this.empid = empid;
	}

	@Override
	public String toString() {
		return "Leave [leaveId=" + leaveId + ", name=" + name + ", reason=" + reason + ", fromDate=" + fromdate
				+ ", toDate=" + todate + ", status=" + status + ", empid=" + empid + "]";
	}
}